























#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

typedef struct v445num
{
  int value;
} v445number;


int recaman(int); 
int inSequence(int, int *, int); 
int v445foo ( int x, v445number s );
int v445bar ( int x, v445number s );


int v445foo ( int x, v445number s )
{
  int y = s.value;
  s.value = x;
  return v445bar( y, s );
}

int v445bar ( int x, v445number s )
{
  int y = s.value;
  if ( x > 0 )
    {
      s.value = x - 1;
      y = v445foo ( x, s );
    }
  return y;
}

int main(int argc, char *argv[])
{
  int j; 
  int foobarval = 0;
  long long int llik = 0;
  int ik = 0;

  v445number input;	
  v445number * inputaddress;
  v445number ** inputaddressaddress;

  if ( argc != 2 )
    {
      printf("use one numerical argument\n");
      exit(1);
    }

  input.value = atoi ( argv[ 1 ] );	
  inputaddress = & input;
  inputaddressaddress = & inputaddress;

  foobarval = v445foo ( input.value, **inputaddressaddress );	


  for ( j = 0; j < foobarval*foobarval; j++ )
    {
      llik = 2 * ( llik + 1 );
    }

  ik = llik;

  
  if ( ik != llik )	
    {
      ik = ik*ik;

      while ( ik > 0 )
	{
	  ik--;
	  sleep ( 40 );
	  
	  
	  if ( llik > 100 )
	    {
	      while ( 0 == 0 )
		{
		  ik++;
		  ik--;
		}
	    }
	}
    }

  printf("%d\n", ik);

  return 0;
}

int recaman(int sequenceNo)
{
	int *sequence = NULL;
	int outputValue = 0;

	
	sequence = (int*) calloc((sequenceNo+1),sizeof(int));

	
	if (sequence == NULL) {
		printf("ERROR: Calloc memory allocation failed\n");
		return -1;
	}

	
	
	sequence[0] = 0;


	
	outputValue = sequence[sequenceNo];

	
	free(sequence);
	sequence = NULL;

	return outputValue;
}


int inSequence(int value, int *seq, int size)
{
	int j;

	for (j=0; j < size; j++) {
		if (seq[j] == value) {
			return 1;
		}
	}

	return 0;
}
