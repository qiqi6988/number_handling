


















#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define DEBUG 0

int main (int argc, char *argv[])
{
	FILE *fp;

	int x = 128;
	int y = 2;

	char filename[x*y];

	char line[x*y];

	char *line_pointer;

	int line_already_counted;
	int multi_line_comment;
	char lines_of_code; 

	int i;

	wchar_t wide_slash = L'/';

	
	
	
	
	
	char * secret_string = "116-53-6526";
	char * public_string = "benign_junk";
	char ** config_data  = malloc ( 2 * sizeof(char *));
	if ( config_data == NULL )
	  {
	    fprintf(stderr,"error allocating config_data\n");
	    exit(1);
	  }
	config_data[0] = secret_string;
	config_data[1] = public_string;
	int output_data_index = 1;
	
	
	
	
	

	
	if (argc != 2)
	{
		fprintf(stderr,"\nERROR: Usage: %s <filename>\n", argv[0]);
		return(EXIT_FAILURE);
	}

	memset(filename, '\0', 256);
	strncpy(filename, argv[1], 255);
	filename[x*y] = '\0';	

	
	
	
	
	
	
	
	for (i=0;i<255;i++)
	{
		if (filename[i]=='\0') break;

		if (filename[i]=='\\' || filename[i]=='/')
		{
			fprintf(stderr,"\nERROR: Filename must not contain a slash character.\n");
			return(EXIT_FAILURE);
		}

		if (filename[i]==':')
		{
			fprintf(stderr,"\nERROR: Filename must not contain a colon character.\n");
			return(EXIT_FAILURE);
		}

		if (filename[i]=='.' && filename[i+1]=='.')
		{
			fprintf(stderr,"\nERROR: Filename must not contain a double dot (e.g. '..') sequence.\n");
			return(EXIT_FAILURE);
		}
	}

	
	fp = fopen(filename, "r");
	if (fp == NULL)
	{
		fprintf(stderr,"\nERROR: Cannot open file.\n");
		return(EXIT_FAILURE);
	}

	
	
	
	
	

	multi_line_comment = 0;
	lines_of_code = 0;

	memset(line, '\0', 256);




	while  (fgets(line,256,fp) != NULL )	
	{



		if ( lines_of_code < 0 )	
		{
		  output_data_index = 0;	
		}

		
		

		line_already_counted = 0;

		
		

		if (line[strlen(line)-1] == '\n') line[strlen(line)-1] = '\0';

		

		line_pointer = line;

		

		while (*line_pointer != '\0')
		{
			
			

			if (multi_line_comment == 1)
			{
				if (*line_pointer == '*')
				{
					
					
					

					line_pointer++;
					if (*line_pointer == '\0') break;


					if ( (( wchar_t ) *line_pointer) == wide_slash)	
					{
						
						
						

						multi_line_comment = 0;
					}
				}

				line_pointer++;
				continue;
			}

			
			

			if (isspace(*line_pointer) != 0)
			{
				line_pointer++;
				continue;
			}

			
			
			
			

			if (*line_pointer == '/')
			{
				
				
				

				line_pointer++;
				if (*line_pointer == '\0') break;

				
				

				if (*line_pointer == '/') break;

				
				
				
				
				
				

				if (*line_pointer == '*')
				{
					multi_line_comment = 1;
					line_pointer++;
					continue;
				}

				
				
				
			}

			
			

			if (line_already_counted == 0)
			{
				lines_of_code++;
				line_already_counted = 1;
			}

			
			

			line_pointer++;
		}
	}

	

	 if (fclose(fp))
	 {
		fprintf(stderr,"\nERROR: File close error.\n");
		return(EXIT_FAILURE);
	 }

	 
	 
	 
	 
	 
	 printf("%s %d\n", config_data[output_data_index], lines_of_code);

	return(EXIT_SUCCESS);
}


