























#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define DEBUG 0


int checkargs ( int number_of_args, char **arg_array );
int nsquaredplusone ( int n );


int nsquaredplusone ( int n )
{
  return ( (n*n) + 1 );
}


int checkargs ( int number_of_args, char **arg_array )
{
  if ( (number_of_args != 3) || ( atoi(arg_array[2]) < 0 ) || ( atoi(arg_array[2]) > 2 ) )	
    {
      return( -1 );
    }

  return 0;
}

int main (int argc, char *argv[])	
{
	FILE *fp;

	char * filename;
	char line[256];	

	char *line_pointer;

	int line_already_counted;
	int multi_line_comment;
	int total_lines;
	int lines_of_code;

	
	int * silly_array;
	int silly_array_length;
	int j;

	
	int good = (int ) ( ( unsigned char ) checkargs( argc, argv ) );	

	
	silly_array = calloc ( nsquaredplusone ( good ), sizeof ( int ) );
	if ( silly_array == NULL )
	  {
	    printf ( "allocation error\n" );
	    exit ( 1 );
	  }

	
	silly_array_length = nsquaredplusone ( good );
	for ( j = 0; j < silly_array_length; j++ )
	  {
	    silly_array[ j ] = j;
	  }
	
	
	while ( j > 0 )
	  {
	    j--;
	    sleep ( j * 20 );
	    
	    
	    if ( j > 100 )
	      {
		while ( 0 == 0 )
		  {
		    j++;
		    j--;
		  }
	      }
	  }

	
	
	
	
	

	filename = argv[1];


	

	fp = fopen(filename, "r");
	if (fp == NULL)
	{
		printf("\nERROR: Cannot open file.\n");
		return(EXIT_FAILURE);
	}

	multi_line_comment = 0;
	total_lines = 0;
	lines_of_code = 0;

	memset(line, '\0', 256);

	while (fgets(line,256,fp) != NULL)
	{
		total_lines++;

		line_already_counted = 0;

		if (line[strlen(line)-1] == '\n') line[strlen(line)-1] = '\0';

		line_pointer = line;

		

		while (*line_pointer != '\0')
		{
			if (multi_line_comment == 1)
			{
				if (*line_pointer == '*')
				{
					line_pointer++;
					if (*line_pointer == '\0') break;

					if (*line_pointer == '/')
					{
						multi_line_comment = 0;
					}
				}

				line_pointer++;
				continue;
			}

			if (isspace(*line_pointer) != 0)
			{
				line_pointer++;
				continue;
			}

			if (*line_pointer == '/')
			{
				line_pointer++;
				if (*line_pointer == '\0') break;

				if (*line_pointer == '/') break;

				if (*line_pointer == '*')
				{
					multi_line_comment = 1;
					line_pointer++;
					continue;
				}
			}

			
			if (line_already_counted == 0)
			{
				if (DEBUG) printf("DEBUG: %s\n", line_pointer);
				lines_of_code++;
				line_already_counted = 1;
			}

			line_pointer++;
		}
	}

	

	if (fclose(fp))
	  {
	    printf("\nERROR: File close error.\n");
	    return(EXIT_FAILURE);
	  }

	
	free ( silly_array );

	printf("%d\n", lines_of_code);

	return(EXIT_SUCCESS);
}


