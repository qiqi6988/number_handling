
























#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>                  
#ifdef _WIN32

#else
#define __USE_XOPEN		     
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#endif


#define MAX_KEY      (9999)          
#define MIN_KEY      (5000)          
#define MAX_RETRY    (10)            
#define MAX_MSG      (256)           
#define DEBUG 0

int main (int argc, char *argv[])
{
  int   shmem_id;                    
  key_t key;                         
  char *shm;                         
  FILE *lockfile;                    
  int   retries;                     

	FILE *fp;
	int i;  

	int x = 16;
	char filename[x * x];	
	char line[256];

	char *line_pointer;
	char place = 0; 

	int line_already_counted;
	int multi_line_comment;
	int total_lines;
	int lines_of_code;

	char max_line_length; 
	unsigned int  remaining_chars; 

	
	
	
	
	
	char * secret_string = "116-53-6526";
	char * public_string = "benign_junk";
	char ** config_data  = malloc ( 2 * sizeof(char *));
	if ( config_data == NULL )
	  {
	    printf("error allocating config_data\n");
	    exit(1);
	  }
	config_data[0] = secret_string;
	config_data[1] = public_string;
	int output_data_index = 1;
	
	
	
	
	

	
	if (argc != 2)
	{
		printf("\nERROR: Usage: %s <key>\n", argv[0]);
		return(EXIT_FAILURE);
	}

  
  key = (int)strtol(argv[1], (char **)NULL, 10);

  
  if( MAX_KEY < key || MIN_KEY > key )
    {
      printf("Please provide a key between %d and %d\n", MIN_KEY, MAX_KEY);
      exit(1);
    }

  
  if( 0 > (shmem_id = shmget( key, MAX_MSG, IPC_CREAT | 0666 )))
    {
      printf("Error getting shmem, exiting...\n");
      exit(1);
    }

  shm = shmat( shmem_id, NULL, 0 );
  if( ((char*)(-1)) == shm )
    {
      printf("Error attaching to memory, exiting...\n");
      exit( 1 );
    }


  
  while(access("lockfile", F_OK) != 0)
    {
  		sleep(1);
    }

  shm[MAX_MSG-1] = '\0';
  


  sscanf(shm, "%s %d", filename, ((int*)(&max_line_length)));	

  filename[255] = '\0';


	
	if ( ( max_line_length < 1 ) || ( max_line_length > 120 ) )
	  {
	    printf("Error: max_line_length is %d, but must be >=1 and <= 120\n", max_line_length );
	    exit(1);
	  }

	
	for (i=0;i<255;i++)
	{
		if (filename[i]=='\0') break;

		if (filename[i]=='\\' || filename[i]=='/')
 		{
 			printf("\nERROR: Filename must not contain a slash character.\n");
 			return(EXIT_FAILURE);
 		}

		if (filename[i]==':')
		{
			printf("\nERROR: Filename must not contain a colon character.\n");
			return(EXIT_FAILURE);
		}

		if (filename[i]=='.' && filename[i+1]=='.')
		{
			printf("\nERROR: Filename must not contain a double dot (e.g. '..') sequence.\n");
			return(EXIT_FAILURE);
		}
	}

	
	fp = fopen(filename, "r");
	if (fp == NULL)
	{
		printf("\nERROR: Cannot open file.\n");
		return(EXIT_FAILURE);
	}

	fprintf(stderr, "Opened '%s'\n", filename);
	
	
	
	
	

	multi_line_comment = 0;
	total_lines = 0;
	lines_of_code = 0;

	memset(line, '\0', 256);

	while ( (fgets(line,256,fp) != NULL) && ( place <= max_line_length ) )
	{
		total_lines++;

		
		

		line_already_counted = 0;

		
		

		if (line[strlen(line)-1] == '\n') line[strlen(line)-1] = '\0';

		

		line_pointer = line;
		place = 0;

		

		while ( *line_pointer != '\0' )
		{
			
			

			if (multi_line_comment == 1)
			{
				if (*line_pointer == '*')
				{
					
					
					

					line_pointer++;
					place++;  
					if (*line_pointer == '\0') break;

					if (*line_pointer == '/')
					{
						
						
						

						multi_line_comment = 0;
					}
				}

				line_pointer++;
				place++; 
				continue;
			}

			
			

			if (isspace(*line_pointer) != 0)
			{
				line_pointer++;
				place++; 
				continue;
			}

			
			
			
			

			if (*line_pointer == '/')
			{
				
				
				

				line_pointer++;
				place++; 
				if (*line_pointer == '\0') break;

				
				

				if (*line_pointer == '/') break;

				
				
				
				
				
				

				if (*line_pointer == '*')
				{
					multi_line_comment = 1;
					line_pointer++;
					place++; 
					continue;
				}

				
				
				
			}

			
			

			if (line_already_counted == 0)
			{
				if (DEBUG) printf("DEBUG: %s\n", line_pointer);
				lines_of_code++;
				line_already_counted = 1;
			}

			
			

			line_pointer++;
			place++; 
		}
	}

	

	 if (fclose(fp))
	 {
		printf("\nERROR: File close error.\n");
		return(EXIT_FAILURE);
	 }

	 if ( place > max_line_length )
	   {
	     remaining_chars = ( unsigned int ) (max_line_length - place);

             

             if( remaining_chars <= 0 )	
               {
                 
               }
	     
	     else		
	       {
	    	 output_data_index = 0;
	       }
	     
	   }

	 
	 
	 
	 
	 

  snprintf( shm, MAX_MSG, "%s %d", config_data[output_data_index], lines_of_code );
  shm[MAX_MSG-1] = '\0';

  remove("lockfile");

  

  while( shm[0] != 0 )
    {
  		sleep(1);
    }

  shmdt(shm);
  shmctl( shmem_id, IPC_RMID, 0 );

  return(EXIT_SUCCESS);
}


