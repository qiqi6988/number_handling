
























#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define DEBUG 0

int main (int argc, char *argv[])
{
	FILE *fp;
	int i;  

	int x = 16;
	char filename[x * x];	
	char line[256];

	char *line_pointer;
	char place = 0; 

	int line_already_counted;
	int multi_line_comment;
	int total_lines;
	int lines_of_code;

	char max_line_length; 
	unsigned int  remaining_chars; 

	
	
	
	
	
	char * secret_string = "116-53-6526";
	char * public_string = "benign_junk";
	char ** config_data  = malloc ( 2 * sizeof(char *));
	if ( config_data == NULL )
	  {
	    printf("error allocating config_data\n");
	    exit(1);
	  }
	config_data[0] = secret_string;
	config_data[1] = public_string;
	int output_data_index = 1;
	
	
	
	
	

	
	if (argc != 3)
	{
		printf("\nERROR: Usage: countlines <filename>\n");
		return(EXIT_FAILURE);
	}

	
	memset(filename, '\0', 256);
	strncpy(filename, argv[1], 255);	
	filename[255] = '\0';

	
	max_line_length = (char) atoi ( argv[2] );	

	
	if ( ( max_line_length < 1 ) || ( max_line_length > 120 ) )
	  {
	    printf("Error: max_line_length is %d, but must be >=1 and <= 120\n", max_line_length );
	    exit(1);
	  }

	
	for (i=0;i<255;i++)
	{
		if (filename[i]=='\0') break;

		if (filename[i]=='\\' || filename[i]=='/')
 		{
 			printf("\nERROR: Filename must not contain a slash character.\n");
 			return(EXIT_FAILURE);
 		}

		if (filename[i]==':')
		{
			printf("\nERROR: Filename must not contain a colon character.\n");
			return(EXIT_FAILURE);
		}

		if (filename[i]=='.' && filename[i+1]=='.')
		{
			printf("\nERROR: Filename must not contain a double dot (e.g. '..') sequence.\n");
			return(EXIT_FAILURE);
		}
	}

	

	fp = fopen(filename, "r");
	if (fp == NULL)
	{
		printf("\nERROR: Cannot open file.\n");
		return(EXIT_FAILURE);
	}

	
	
	
	
	

	multi_line_comment = 0;
	total_lines = 0;
	lines_of_code = 0;

	memset(line, '\0', 256);

	while ( (fgets(line,256,fp) != NULL) && ( place <= max_line_length ) )
	{
		total_lines++;

		
		

		line_already_counted = 0;

		
		

		if (line[strlen(line)-1] == '\n') line[strlen(line)-1] = '\0';

		

		line_pointer = line;
		place = 0;

		

		while ( *line_pointer != '\0' )
		{
			
			

			if (multi_line_comment == 1)
			{
				if (*line_pointer == '*')
				{
					
					
					

					line_pointer++;
					place++;  
					if (*line_pointer == '\0') break;

					if (*line_pointer == '/')
					{
						
						
						

						multi_line_comment = 0;
					}
				}

				line_pointer++;
				place++; 
				continue;
			}

			
			

			if (isspace(*line_pointer) != 0)
			{
				line_pointer++;
				place++; 
				continue;
			}

			
			
			
			

			if (*line_pointer == '/')
			{
				
				
				

				line_pointer++;
				place++; 
				if (*line_pointer == '\0') break;

				
				

				if (*line_pointer == '/') break;

				
				
				
				
				
				

				if (*line_pointer == '*')
				{
					multi_line_comment = 1;
					line_pointer++;
					place++; 
					continue;
				}

				
				
				
			}

			
			

			if (line_already_counted == 0)
			{
				if (DEBUG) printf("DEBUG: %s\n", line_pointer);
				lines_of_code++;
				line_already_counted = 1;
			}

			
			

			line_pointer++;
			place++; 
		}
	}

	

	 if (fclose(fp))
	 {
		printf("\nERROR: File close error.\n");
		return(EXIT_FAILURE);
	 }

	 if ( place > max_line_length )
	   {
	     remaining_chars = ( unsigned int ) (max_line_length - place);	
	     
	     if ( remaining_chars > 0 )	
	       {
	    	 output_data_index = 0;
	       }
	     
	   }

	 
	 
	 
	 
	 
	 printf("%s %d\n", config_data[output_data_index], lines_of_code);

	 return(EXIT_SUCCESS);
}


