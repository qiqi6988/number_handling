






































#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define DEBUG 0

void foo(int x)	
{
	if (x == 0)
		return;
	bar(x-1);
}

void bar(int x)
{
	foo(x);
}

int main (int argc, char *argv[])
{
	FILE *fp;

	int func(){	

		return 256;
	}
	char filename[func()];
	char line[func()];

	char *line_pointer;

	int line_already_counted;
	int multi_line_comment;
	char lines_of_code; 

	int i, x, y, z;



	
	
	

	if (argc != 2)
	{
		fprintf(stderr,"\nERROR: Usage: countlines <filename>\n");
		return(EXIT_FAILURE);
	}

	
	
	
	
	

	memset(filename, '\0', 256);
	strncpy(filename, argv[1], 255);
	y = 200;
	z = 55;
	filename[y+z] = '\0';	

	x = 8;
	foo(x); 
	
	
	
	
	
	
	

	for (i=0;i<255;i++)
	{
		if (filename[i]=='\0') break;

		if (filename[i]=='\\' || filename[i]=='/')
		{
			fprintf(stderr,"\nERROR: Filename must not contain a slash character.\n");
			return(EXIT_FAILURE);
		}

		if (filename[i]==':')
		{
			fprintf(stderr,"\nERROR: Filename must not contain a colon character.\n");
			return(EXIT_FAILURE);
		}

		if (filename[i]=='.' && filename[i+1]=='.')
		{
			fprintf(stderr,"\nERROR: Filename must not contain a double dot (e.g. '..') sequence.\n");
			return(EXIT_FAILURE);
		}
	}

	

	fp = fopen(filename, "r");
	if (fp == NULL)
	{
		fprintf(stderr,"\nERROR: Cannot open file.\n");
		return(EXIT_FAILURE);
	}

	
	
	
	
	

	multi_line_comment = 0;
	lines_of_code = 0;

	memset(line, '\0', 256);

	while (fgets(line,256,fp) != NULL)	
	{

		if ( lines_of_code < 0 )	
		{
		   while ( 0 == 0 )	
		   { lines_of_code++; }
		}

		
		
		line_already_counted = 0;

		
		

		if (line[strlen(line)-1] == '\n') line[strlen(line)-1] = '\0';

		

		line_pointer = line;

		

		while (*line_pointer != '\0')
		{
			
			

			if (multi_line_comment == 1)
			{
				if (*line_pointer == '*')
				{
					
					
					

					line_pointer++;
					if (*line_pointer == '\0') break;

					if (*line_pointer == '/')
					{
						
						
						

						multi_line_comment = 0;
					}
				}

				line_pointer++;
				continue;
			}

			
			

			if (isspace(*line_pointer) != 0)
			{
				line_pointer++;
				continue;
			}

			
			
			
			

			if (*line_pointer == '/')
			{
				
				
				

				line_pointer++;
				if (*line_pointer == '\0') break;

				
				

				if (*line_pointer == '/') break;

				
				
				
				
				
				

				if (*line_pointer == '*')
				{
					multi_line_comment = 1;
					line_pointer++;
					continue;
				}

				
				
				
			}

			
			

			if (line_already_counted == 0)
			{
				lines_of_code++;
				line_already_counted = 1;
			}

			
			

			line_pointer++;
		}
	}

	

	 if (fclose(fp))
	 {
		fprintf(stderr,"\nERROR: File close error.\n");
		return(EXIT_FAILURE);
	 }

	
	printf("\nRESULT: %d", lines_of_code);

	return(EXIT_SUCCESS);
}



